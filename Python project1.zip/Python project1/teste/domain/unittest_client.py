from unittest import TestCase
import unittest


class TestEntitate(TestCase):
    def setUp(self):
        from domain.entitate import Entitate
        self.entitate = Entitate("1")

    def testGetIdEntitate(self):
        self.assertTrue(self.entitate.getIdEntitate() == "1")

    def testSetIdEntitate(self):
        self.entitate.setIdEntitate("2")
        self.assertTrue(self.entitate.getIdEntitate() == "2")


class TestClient(TestCase):
    def setUp(self):
        from domain.client import Client
        self.client = Client("1", "Ion", 123)

    def testGetteri(self):
        self.assertTrue(self.client.getIdEntitate() == "1")
        self.assertTrue(self.client.getNume() == "Ion")
        self.assertTrue(self.client.getCnp() == 123)

    def testSetteri(self):
        self.client.setIdEntitate("2")
        self.assertTrue(self.client.getIdEntitate() == "2")

        self.client.setNume("Marcel")
        self.assertTrue(self.client.getNume() == "Marcel")

        self.client.setCnp(456)
        self.assertTrue(self.client.getCnp() == 456)

    def test_str(self):
        self.assertTrue(
            self.client.__str__() == "id: " + self.client.getIdEntitate() + ", nume: " + self.client.getNume() + \
            ", cnp: " + str(self.client.getCnp()))

    def tearDown(self) -> None:
        pass
