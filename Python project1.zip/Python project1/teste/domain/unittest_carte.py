from unittest import TestCase
import unittest


class TestEntitate(TestCase):
    def setUp(self):
        from domain.entitate import Entitate
        self.entitate = Entitate("1")

    def testGetIdEntitate(self):
        self.assertTrue(self.entitate.getIdEntitate() == "1")

    def testSetIdEntitate(self):
        self.entitate.setIdEntitate("2")
        self.assertTrue(self.entitate.getIdEntitate() == "2")


class TestCarte(TestCase):
    def setUp(self):
        from domain.carte import Carte
        self.carte = Carte("1", "Castelul", "Ion", "interesant")

    def testGetteri(self):
        self.assertTrue(self.carte.getIdEntitate() == "1")
        self.assertTrue(self.carte.getTitlu() == "Castelul")
        self.assertTrue(self.carte.getAutor() == "Ion")
        self.assertTrue(self.carte.getDescriere() == "interesant")

    def testSetteri(self):
        self.carte.setIdEntitate("2")
        self.assertTrue(self.carte.getIdEntitate() == "2")
        self.assertTrue(self.carte.getIdEntitate() == "2")

        self.carte.setTitlu("Palatul")
        self.assertTrue(self.carte.getTitlu() == "Palatul")

        self.carte.setAutor("Ana")
        self.assertTrue(self.carte.getAutor() == "Ana")

        self.carte.setDescriere("nice")
        self.assertTrue(self.carte.getDescriere() == "nice")

    def test_str(self):
        self.assertTrue(
            self.carte.__str__() == "id: " + self.carte.getIdEntitate() + ", titlu: " + self.carte.getTitlu() + \
            ", autor: " + self.carte.getAutor() + ", descriere: " + self.carte.getDescriere())

    def tearDown(self) -> None:
        pass
