from unittest import TestCase
import unittest


class TestEntitate(TestCase):
    def setUp(self):
        from domain.entitate import Entitate
        self.entitate = Entitate("1")

    def testGetIdEntitate(self):
        self.assertTrue(self.entitate.getIdEntitate() == "1")

    def testSetIdEntitate(self):
        self.entitate.setIdEntitate("2")
        self.assertTrue(self.entitate.getIdEntitate() == "2")


class TestClient(TestCase):
    def setUp(self):
        from domain.inchiriere import Inchiriere
        self.inchiriere = Inchiriere("1", "2", "3")

    def testGetteri(self):
        self.assertTrue(self.inchiriere.getIdEntitate() == "3")
        self.assertTrue(self.inchiriere.getIdClient() == "1")
        self.assertTrue(self.inchiriere.getIdCarte() == "2")

    def testSetteri(self):
        self.inchiriere.setIdEntitate("6")
        self.assertTrue(self.inchiriere.getIdEntitate() == "6")

        self.inchiriere.setIdClient("7")
        self.assertTrue(self.inchiriere.getIdClient() == "7")

        self.inchiriere.setIdCarte("8")
        self.assertTrue(self.inchiriere.getIdCarte() == "8")

    def test_str(self):
        self.assertTrue(
            self.inchiriere.__str__() == "Inchiriere: " + self.inchiriere.getIdEntitate() + ", ID Client: " + self.inchiriere.getIdClient() + \
            ", ID Carte: " + str(self.inchiriere.getIdCarte()))

    def tearDown(self) -> None:
        pass
