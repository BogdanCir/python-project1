from unittest import TestCase
import unittest
from domain.inchiriere import Inchiriere


class TestInchiriereFileRepository(TestCase):
    def setUp(self):
        from repository.inchiriereFileRepository import InchiriereFileRepository
        self.inchiriereRepository = InchiriereFileRepository("C:/Users/diana/Desktop/lab_11/teste/repository/unittest_inchiriere_file_repository")

    def test_load_data(self):
        inchirieri = self.inchiriereRepository.getAll()
        assert len(inchirieri) == 2
        assert inchirieri[0].getIdClient() == "1"
        assert inchirieri[1].getIdClient() == "2"
        assert inchirieri[0].getIdCarte() == "1"
        assert inchirieri[1].getIdCarte() == "4"
        assert inchirieri[0].getIdEntitate() == "1"
        assert inchirieri[1].getIdEntitate() == "5"

    def testAdauga(self):
        inchiriere = Inchiriere("3", "3", "888")
        self.inchiriereRepository.adauga(inchiriere)
        inchirieri = self.inchiriereRepository.getAll()
        assert len(inchirieri) == 3
        assert inchirieri[2].getIdEntitate() == "888"
        assert inchirieri[2].getIdClient() == "3"
        assert inchirieri[2].getIdCarte() == "3"
        self.inchiriereRepository.sterge("888")

    def testSterge(self):
        self.inchiriereRepository.sterge("5")
        inchirieri = self.inchiriereRepository.getAll()
        assert len(inchirieri) == 1
        inchiriere = Inchiriere("2", "4", "5")
        self.inchiriereRepository.adauga(inchiriere)

    def testModifica(self):
        inchiriereNoua = Inchiriere("6", "7", "5")
        self.inchiriereRepository.modifica(inchiriereNoua)

        inchirieri = self.inchiriereRepository.getAll()
        assert len(inchirieri) == 2
        self.assertTrue(inchirieri[0].getIdEntitate() == "1")
        assert inchirieri[0].getIdEntitate() == "1"
        assert inchirieri[1].getIdEntitate() == "5"
        assert inchirieri[0].getIdClient() == "1"
        assert inchirieri[1].getIdClient() == "6"
        assert inchirieri[0].getIdCarte() == "1"
        assert inchirieri[1].getIdCarte() == "7"

        inchiriereVeche = Inchiriere("2", "4", "5")
        self.inchiriereRepository.modifica(inchiriereVeche)

    def tearDown(self) -> None:
        pass
