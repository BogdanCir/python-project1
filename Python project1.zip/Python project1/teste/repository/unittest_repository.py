from unittest import TestCase
import unittest
from domain.client import Client


class TestRepository(TestCase):
    def setUp(self):
        from domain.client import Client
        from repository.repository import Repository
        self.clientRepository = Repository()
        self.client = Client("1", "Marcel", 123)
        self.clientRepository.adauga(self.client)

    def testAdaugaClient(self):
        from domain.exceptions.duplicateError import DuplicateError
        clienti = self.clientRepository.getAll()
        assert len(clienti) == 1
        assert clienti[0].getIdEntitate() == "1"

        try:
            self.clientRepository.adauga(self.client)
        except DuplicateError:
            assert True

    def testModificaClient(self):
        clientNou = Client("1", "Jupiter", 456)
        clientNouu = Client("2", "marcel", 666)
        self.clientRepository.modifica(clientNou)

        clienti = self.clientRepository.getAll()
        assert len(clienti) == 1
        assert clienti[0].getIdEntitate() == "1"
        assert clienti[0].getNume() == "Jupiter"
        assert clienti[0].getCnp() == 456

        try:
            self.clientRepository.modifica(clientNouu)
        except KeyError:
            assert True

    def testStergeClient(self):
        self.clientRepository.sterge("1")

        try:
            self.clientRepository.sterge("1")
        except KeyError:
            assert True

    def tearDown(self) -> None:
        pass
