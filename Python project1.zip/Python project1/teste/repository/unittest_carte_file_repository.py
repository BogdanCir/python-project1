from unittest import TestCase
import unittest
from domain.carte import Carte


class TestCarteFileRepository(TestCase):
    def setUp(self):
        from repository.carteFileRepository import CarteFileRepository
        self.carteRepository = \
            CarteFileRepository("unittest_carte_file_repository")

    def test_load_data(self):
        carti = self.carteRepository.getAll()
        assert len(carti) == 2
        assert carti[0].getIdEntitate() == "1"
        assert carti[1].getIdEntitate() == "2"
        self.assertTrue(carti[0].getTitlu() == "Igiena asasinului")
        self.assertTrue(carti[0].getAutor() == "Amelie Northomb")
        self.assertTrue(carti[0].getDescriere() == "roman")
        self.assertTrue(carti[1].getTitlu() == "Metamorfoza")
        self.assertTrue(carti[1].getAutor() == "Franz Kafka")
        self.assertTrue(carti[1].getDescriere() == "cu gandaci")

    def testAdauga(self):
        carte = Carte("3", "Ionatana", "aaa", "aaa")
        self.carteRepository.adauga(carte)
        carti = self.carteRepository.getAll()
        assert len(carti) == 3
        assert carti[2].getIdEntitate() == "3"
        assert carti[2].getTitlu() == "Ionatana"
        assert carti[2].getAutor() == "aaa"
        assert carti[2].getDescriere() == "aaa"
        self.carteRepository.sterge("3")

    def testSterge(self):
        self.carteRepository.sterge("2")
        carti = self.carteRepository.getAll()
        assert len(carti) == 1
        carte = Carte("2", "Metamorfoza", "Franz Kafka", "cu gandaci")
        self.carteRepository.adauga(carte)

    def testModifica(self):
        carteNoua = Carte("2", "Patricia", "9999", "a")
        self.carteRepository.modifica(carteNoua)

        carti = self.carteRepository.getAll()
        assert len(carti) == 2
        self.assertTrue(carti[0].getIdEntitate() == "1")
        assert carti[1].getIdEntitate() == "2"
        assert carti[1].getTitlu() == "Patricia"
        assert carti[1].getAutor() == "9999"
        assert carti[1].getDescriere() == "a"

        carteVeche = Carte("2", "Metamorfoza", "Franz Kafka", "cu gandaci")
        self.carteRepository.modifica(carteVeche)

    def tearDown(self) -> None:
        pass
