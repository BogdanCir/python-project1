from unittest import TestCase
import unittest
from domain.client import Client


class TestClientFileRepository(TestCase):
    def setUp(self):
        from repository.clientFileRepository import ClientFileRepository
        self.clientRepository = ClientFileRepository("C:/Users/diana/Desktop/lab_11/teste/repository/unittest_client_file_repository")

    def test_load_data(self):
        clienti = self.clientRepository.getAll()
        assert len(clienti) == 2
        assert clienti[0].getIdEntitate() == "1"
        assert clienti[1].getIdEntitate() == "2"
        assert clienti[0].getNume() == "Marcel"
        assert clienti[1].getNume() == "Ana"
        assert clienti[0].getCnp() == 123
        assert clienti[1].getCnp() == 456

    def testAdauga(self):
        client = Client("3", "Ionatana", 888)
        self.clientRepository.adauga(client)
        clienti = self.clientRepository.getAll()
        assert len(clienti) == 3
        assert clienti[2].getIdEntitate() == "3"
        assert clienti[2].getNume() == "Ionatana"
        assert clienti[2].getCnp() == 888
        self.clientRepository.sterge("3")

    def testSterge(self):
        self.clientRepository.sterge("2")
        clienti = self.clientRepository.getAll()
        assert len(clienti) == 1
        client = Client("2", "Ana", 456)
        self.clientRepository.adauga(client)

    def testModifica(self):
        clientNou = Client("2", "Patricia", 9999)
        self.clientRepository.modifica(clientNou)

        clienti = self.clientRepository.getAll()
        assert len(clienti) == 2
        self.assertTrue(clienti[0].getIdEntitate() == "1")
        assert clienti[1].getIdEntitate() == "2"
        assert clienti[0].getNume() == "Marcel"
        assert clienti[1].getNume() == "Patricia"
        assert clienti[0].getCnp() == 123
        assert clienti[1].getCnp() == 9999

        clientVechi = Client("2", "Ana", 456)
        self.clientRepository.modifica(clientVechi)



    def tearDown(self) -> None:
        pass
