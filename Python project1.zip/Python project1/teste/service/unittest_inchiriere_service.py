from unittest import TestCase
import unittest


class TestInchiriereService(TestCase):
    def setUp(self):
        from repository.repository import Repository
        from service.carteService import CarteService
        from service.clientService import ClientService
        from service.inchiriereService import InchiriereService

        clientRepository = Repository()
        carteRepository = Repository()
        inchiriereRepository = Repository()
        self.inchiriereService = InchiriereService(inchiriereRepository, clientRepository, carteRepository)

        clientService = ClientService(clientRepository, inchiriereRepository)
        clientService.adauga("1", "Iacob", 888)
        carteService = CarteService(carteRepository, inchiriereRepository)
        carteService.adauga("2", "Dune", "Frank herbert", "complicat")

        self.inchiriereService.adaugaInchiriere("1", "2", "10")

    def testAdaugaInchiriereService(self):
        from domain.exceptions.duplicateError import DuplicateError
        inchirieri = self.inchiriereService.getAllInchirieri()
        assert len(inchirieri) == 1
        assert inchirieri[0].getIdEntitate() == "10"
        assert inchirieri[0].getIdClient() == "1"
        assert inchirieri[0].getIdCarte() == "2"

        try:
            self.inchiriereService.adaugaInchiriere("2", "2", "2")
        except KeyError:
            ...

        try:
            self.inchiriereService.adaugaInchiriere("1", "3", "2")
        except KeyError:
            ...

        try:
            self.inchiriereService.adaugaInchiriere("1", "2", "10")
        except DuplicateError:
            ...

    def testStergeInchiriereService(self):
        self.inchiriereService.stergeInchiriere("10")
        inchirieri = self.inchiriereService.getAllInchirieri()

        assert len(inchirieri) == 0

        try:
            self.inchiriereService.stergeInchiriere("10")
        except KeyError:
            ...

    def testCeleMaiInchiriateCarti(self):
        from repository.repository import Repository
        from service.carteService import CarteService
        from service.clientService import ClientService
        from service.inchiriereService import InchiriereService

        clientRepository = Repository()
        carteRepository = Repository()
        inchiriereRepository = Repository()
        self.inchiriereService = InchiriereService(inchiriereRepository, clientRepository, carteRepository)

        clientService = ClientService(clientRepository, inchiriereRepository)
        clientService.adauga("1", "Ionel", 33)
        clientService.adauga("2", "Maria", 44)
        clientService.adauga("3", "Ana", 55)
        carteService = CarteService(carteRepository, inchiriereRepository)
        carteService.adauga("1", "aaa", "aaa", "aaa")
        carteService.adauga("2", "bbb", "bbb", "bbb")
        carteService.adauga("3", "ccc", "ccc", "ccc")

        self.inchiriereService.adaugaInchiriere("1", "2", "10")
        self.inchiriereService.adaugaInchiriere("2", "2", "20")
        self.inchiriereService.adaugaInchiriere("3", "1", "30")
        self.inchiriereService.adaugaInchiriere("3", "3", "40")

        dictio = self.inchiriereService.celeMaiInchiriateCarti()
        assert len(dictio) == 3
        assert dictio[" 2"] == 2
        assert dictio["1"] == 1
        assert dictio["3"] == 1

    def testClientiOrdonatiNumeNrCartiInchiriate(self):
        from repository.repository import Repository
        from service.carteService import CarteService
        from service.clientService import ClientService
        from service.inchiriereService import InchiriereService

        clientRepository = Repository()
        carteRepository = Repository()
        inchiriereRepository = Repository()
        self.inchiriereService = InchiriereService(inchiriereRepository, clientRepository, carteRepository)

        clientService = ClientService(clientRepository, inchiriereRepository)
        clientService.adauga("1", "Ionel", 33)
        clientService.adauga("2", "Maria", 44)
        clientService.adauga("3", "Ana", 55)
        carteService = CarteService(carteRepository, inchiriereRepository)
        carteService.adauga("1", "aaa", "aaa", "aaa")
        carteService.adauga("2", "bbb", "bbb", "bbb")
        carteService.adauga("3", "ccc", "ccc", "ccc")

        self.inchiriereService.adaugaInchiriere("1", "2", "10")
        self.inchiriereService.adaugaInchiriere("2", "2", "20")
        self.inchiriereService.adaugaInchiriere("3", "1", "30")
        self.inchiriereService.adaugaInchiriere("3", "3", "40")

        sortat = self.inchiriereService.clientiOrdonatiNumeNrCartiInchiriate()

        assert len(sortat) == 3

        assert sortat[0] == ('Ionel', 1)
        assert sortat[1] == ('Maria', 1)
        assert sortat[2] == ('Ana', 2)

    def testPrimiiCeiMaiActivi(self):
        from repository.repository import Repository
        from service.carteService import CarteService
        from service.clientService import ClientService
        from service.inchiriereService import InchiriereService

        clientRepository = Repository()
        carteRepository = Repository()
        inchiriereRepository = Repository()
        self.inchiriereService = InchiriereService(inchiriereRepository, clientRepository, carteRepository)

        clientService = ClientService(clientRepository, inchiriereRepository)
        clientService.adauga("1", "Ionel", 33)
        clientService.adauga("2", "Maria", 44)
        clientService.adauga("3", "Ana", 55)
        clientService.adauga("4", "Amalia", 66)
        clientService.adauga("5", "Horea", 77)

        carteService = CarteService(carteRepository, inchiriereRepository)
        carteService.adauga("1", "aaa", "aaa", "aaa")
        carteService.adauga("2", "bbb", "bbb", "bbb")
        carteService.adauga("3", "ccc", "ccc", "ccc")

        self.inchiriereService.adaugaInchiriere("1", "2", "10")
        self.inchiriereService.adaugaInchiriere("2", "2", "20")
        self.inchiriereService.adaugaInchiriere("3", "1", "30")
        self.inchiriereService.adaugaInchiriere("3", "3", "40")
        self.inchiriereService.adaugaInchiriere("4", "2", "50")
        self.inchiriereService.adaugaInchiriere("5", "2", "60")

        listaNoua = self.inchiriereService.primiiCeiMaiActivi()

        assert len(listaNoua) == 1
        assert listaNoua[0] == ('Ana', 2)

    def tearDown(self) -> None:
        pass
