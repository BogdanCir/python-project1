from domain.exceptions.duplicateError import DuplicateError
from unittest import TestCase
import unittest


class TestClientService(TestCase):
    def setUp(self):
        from repository.repository import Repository
        from service.clientService import ClientService

        clientRepository = Repository()
        inchiriereRepository = Repository()

        self.clientService = ClientService(clientRepository, inchiriereRepository)
        self.clientService.adauga("1", "Iacob", 888)

    def testAdaugaClientService(self):
        clienti = self.clientService.getAllClienti()
        assert len(clienti) == 1
        assert clienti[0].getIdEntitate() == "1"

        try:
            self.clientService.adauga("1", "Isacob", 889)
        except DuplicateError:
            assert True

    def testModificaClientService(self):
        self.clientService.modifica("1", "Iona", 999)

        clienti = self.clientService.getAllClienti()
        assert len(clienti) == 1
        assert clienti[0].getIdEntitate() == "1"
        assert clienti[0].getNume() == "Iona"
        assert clienti[0].getCnp() == 999

        try:
            self.clientService.modifica("2", "Kakak", 444455)
        except KeyError:
            assert True

    def testStergeClientService(self):
        self.clientService.sterge("1")

        assert len(self.clientService.getAllClienti()) == 0

        try:
            self.clientService.sterge("1")
        except KeyError:
            assert True

    def tearDown(self) -> None:
        pass
