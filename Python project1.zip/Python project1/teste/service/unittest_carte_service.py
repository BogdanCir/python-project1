from unittest import TestCase
import unittest
from domain.exceptions.duplicateError import DuplicateError


class TestCarteService(TestCase):
    def setUp(self):
        from repository.repository import Repository
        from service.carteService import CarteService

        carteRepository = Repository()
        inchiriereRepository = Repository()
        self.carteService = CarteService(carteRepository, inchiriereRepository)
        self.carteService.adauga("1", "Dune", "Frank herbert", "complicat")

    def testAdaugaCarteService(self):
        carti = self.carteService.getAllCarti()

        assert len(carti) == 1
        assert carti[0].getIdEntitate() == "1"

        try:
            self.carteService.adauga("1", "Ian", "pasiv", "dkfjs")
        except DuplicateError:
            assert True

    def testModificaCarteService(self):
        self.carteService.modifica("1", "aaa", "ma", "bbb")

        carti = self.carteService.getAllCarti()

        assert len(carti) == 1
        assert carti[0].getIdEntitate() == "1"
        assert carti[0].getTitlu() == "aaa"
        assert carti[0].getAutor() == "ma"
        assert carti[0].getDescriere() == "bbb"

        try:
            self.carteService.modifica("2", "JOasd", "jdhfhf", "dewfh")
        except KeyError:
            assert True

    def testStergeCarteService(self):
        self.carteService.sterge("1")
        assert len(self.carteService.getAllCarti()) == 0

        try:
            self.carteService.sterge("1")
        except KeyError:
            assert True

    def tearDown(self) -> None:
        pass

