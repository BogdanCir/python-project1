from domain.entitate import Entitate


class Carte(Entitate):
    def __init__(self, idCarte, titlu, autor, descriere):
        super().__init__(idCarte)
        self.__titlu = titlu
        self.__autor = autor
        self.__descriere = descriere

    def getTitlu(self):
        return self.__titlu

    def getAutor(self):
        return self.__autor

    def getDescriere(self):
        return self.__descriere

    def setTitlu(self, titlu):
        self.__titlu = titlu

    def setAutor(self, autor):
        self.__autor = autor

    def setDescriere(self, descriere):
        self.__descriere = descriere

    def __str__(self):
        return f"id: {self.getIdEntitate()}, titlu: {self.__titlu}, autor: {self.__autor}, descriere: {self.__descriere}"