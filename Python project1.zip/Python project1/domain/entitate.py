class Entitate:
    def __init__(self, idEntitate):
        self.__idEntitate = idEntitate

    def getIdEntitate(self):
        return self.__idEntitate

    def setIdEntitate(self, idEntitate):
        self.__idEntitate = idEntitate
