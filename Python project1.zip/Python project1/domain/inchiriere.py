from domain.entitate import Entitate


class Inchiriere(Entitate):
    def __init__(self, idClient, idCarte, id):
        super().__init__(id)
        self.__idClient = idClient
        self.__idCarte = idCarte

    def getIdClient(self):
        return self.__idClient

    def getIdCarte(self):
        return self.__idCarte

    def setIdClient(self, idClient):
        self.__idClient = idClient

    def setIdCarte(self, idCarte):
        self.__idCarte = idCarte

    def __str__(self):
        return f"Inchiriere: {self.getIdEntitate()}, ID Client: {self.__idClient}, ID Carte: {self.__idCarte}"