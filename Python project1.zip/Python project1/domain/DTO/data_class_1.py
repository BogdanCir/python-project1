from dataclasses import dataclass


@dataclass()
class NrInchirieri:
    id_carte: str
    nr_inchirieri: int

# id-urile cartilor si nr de inchirieri ale acestora


class NrInchirieriAssembler:
    def create_nr_inchirieri_dto(carte, inchirieri):
        # inchirieri = lista tuturor inchirierilor

        id_carte = carte.getIdEntitate()
        nr_inchirieri = 0
        for inchiriere in inchirieri:
            if int(inchiriere.getIdCarte()) == int(carte.getIdEntitate()):
                nr_inchirieri += 1

        if nr_inchirieri > 0:
            return NrInchirieri(id_carte, nr_inchirieri)
