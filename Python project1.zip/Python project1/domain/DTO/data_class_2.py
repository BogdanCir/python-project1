from dataclasses import dataclass


@dataclass
class NumeNrInchirieri:
    nume_client: str
    nr_inchirieri: int

# numele clientului si numarul de carti inchiriate de acesta


class NumeNrInchirieriAssembler:
    def create_nume_nr_inchirieri(client, inchirieri):
        nume_client = client.getNume()

        nr_inchirieri = 0
        for inchiriere in inchirieri:
            if int(client.getIdEntitate()) == int(inchiriere.getIdClient()):
                nr_inchirieri += 1

        if nr_inchirieri > 0:
            return NumeNrInchirieri(nume_client, nr_inchirieri)
