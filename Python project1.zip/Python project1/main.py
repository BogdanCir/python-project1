from repository.repository import Repository
from service.carteService import CarteService
from service.clientService import ClientService
from service.inchiriereService import InchiriereService
from ui.consola import Consola
from testing.testAll import testAll
from repository.clientFileRepository import ClientFileRepository
from repository.carteFileRepository import CarteFileRepository
from repository.inchiriereFileRepository import InchiriereFileRepository


def main():
    testAll()

    # clientRepository = Repository()
    clientRepository = ClientFileRepository("clienti.txt")
    # carteRepository = Repository()
    carteRepository = CarteFileRepository("carti.txt")
    # inchiriereRepository = Repository()
    inchiriereRepository = InchiriereFileRepository("inchiriere.txt")

    clientService = ClientService(clientRepository, inchiriereRepository)
    carteService = CarteService(carteRepository, inchiriereRepository)
    inchiriereService = InchiriereService(inchiriereRepository, clientRepository, carteRepository)

    consola = Consola(clientService, carteService, inchiriereService)

    consola.menu()


if __name__ == '__main__':
    main()
