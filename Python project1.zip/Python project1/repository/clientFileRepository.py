from repository.repository import Repository
from domain.client import Client


class ClientFileRepository(Repository):
    def __init__(self, file_name):
        super().__init__()
        self.__file_name = file_name
        self.__load_data()

    def __load_data(self):
        with open(self.__file_name) as f:
            for line in f:
                array = line.strip("\n").split(",")
                client = Client(array[0], array[1], int(array[2]))
                super().adauga(client)

    def adauga(self, client):
        with open(self.__file_name, "a") as f:
            line = client.getIdEntitate() + "," + client.getNume() + "," + str(client.getCnp()) + "\n"
            f.write(line)
            super().adauga(client)

    def modifica(self, clientNou):
        super().modifica(clientNou)
        self.write_data()

    def sterge(self, idClient):
        super().sterge(idClient)
        self.write_data()

    def write_data(self):
        f = open(self.__file_name, "w")
        listaClienti = super().getAll()
        for client in listaClienti:
            line = client.getIdEntitate() + "," + client.getNume() + "," + str(client.getCnp()) + "\n"
            f.write(line)
        f.close()

