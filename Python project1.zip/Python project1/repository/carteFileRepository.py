from domain.carte import Carte
from repository.repository import Repository


class CarteFileRepository(Repository):
    def __init__(self, file_name):
        super().__init__()
        self.__file_name = file_name
        self.__load_data()

    def __load_data(self):
        with open(self.__file_name) as f:
            for line in f:
                array = line.strip("\n").split(",")
                carte = Carte(array[0], array[1], array[2], array[3])
                super().adauga(carte)

    def adauga(self, carte):
        with open(self.__file_name, "a") as f:
            line = carte.getIdEntitate() + "," + carte.getTitlu() + "," + carte.getAutor() + "," + carte.getDescriere() + "\n"
            f.write(line)
            super().adauga(carte)

    def modifica(self, carteNoua):
        super().modifica(carteNoua)
        self.write_data()

    def sterge(self, idCarte):
        super().sterge(idCarte)
        self.write_data()

    def write_data(self):
        f = open(self.__file_name, "w")
        listaCarti = super().getAll()
        for carte in listaCarti:
            line = carte.getIdEntitate() + "," + carte.getTitlu() + "," + carte.getAutor() + "," + carte.getDescriere() + "\n"
            f.write(line)
        f.close()