from domain.inchiriere import Inchiriere
from repository.repository import Repository


class InchiriereFileRepository(Repository):
    def __init__(self, file_name):
        super().__init__()
        self.__file_name = file_name
        self.__load_data()

    def __load_data(self):
        with open(self.__file_name) as f:
            for line in f:
                array = line.strip("\n").split(",")
                inchiriere = Inchiriere(array[0], array[1], array[2])
                super().adauga(inchiriere)

    def adauga(self, inchiriere):
        with open(self.__file_name, "a") as f:
            line = inchiriere.getIdClient() + "," + inchiriere.getIdCarte() + "," + inchiriere.getIdEntitate() + "\n"
            f.write(line)
            super().adauga(inchiriere)

    def sterge(self, idEntitate):
        super().sterge(idEntitate)
        self.write_data()

    def write_data(self):
        f = open(self.__file_name, "w")
        lista_inchirieri = super().getAll()
        for inc in lista_inchirieri:
            line = inc.getIdClient() + "," + inc.getIdCarte() + "," + inc.getIdEntitate() + "\n"
            f.write(line)
        f.close()