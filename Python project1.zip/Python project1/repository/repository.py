from domain.exceptions.duplicateError import DuplicateError


class Repository:
    def __init__(self):
        self.__entitati = {}

    def getAll(self):
        '''
        returneaza o lista a tuturor entitatilor
        :return: o lista de obiecte de tipul Entitate
        '''
        return list(self.__entitati.values())

    def getById(self, idEntitate):
        '''
        returneaza entiatea cu ID-ul introdus
        :param idEntitate: str
        :return: un obiect de tipul Entitate
        '''
        if idEntitate in self.__entitati:
            return self.__entitati[idEntitate]
        return None

    def adauga(self, entitate):
        '''
        adauga o entitate in dictionar
        :param entitate: obiect de tipul Entitate
        :return:
        '''
        if self.getById(entitate.getIdEntitate()) is not None:
            raise DuplicateError("O entitate cu acest ID exista deja!")
        self.__entitati[entitate.getIdEntitate()] = entitate

    def modifica(self, entitateNoua):
        '''
        modifica o entitate dupa ID
        :param entitateNoua: obiect de tipul Entitate
        :return:
        '''
        if self.getById(entitateNoua.getIdEntitate()) is None:
            raise KeyError("Nu exista nicio entitate cu acest Id!")
        self.__entitati[entitateNoua.getIdEntitate()] = entitateNoua

    def sterge(self, idEntitate):
        '''
        sterge o entitate din dictionar dupa ID
        :param idEntitate: str
        :return:
        '''
        if self.getById(idEntitate) is None:
            raise KeyError("Nu exista nicio entitate cu acest ID!")
        self.__entitati.pop(idEntitate)