from domain.exceptions.duplicateError import DuplicateError
from repository.repository import Repository
from service.carteService import CarteService


def testAdaugaCarteService():
    carteRepository = Repository()
    inchiriereRepository = Repository()
    carteService = CarteService(carteRepository, inchiriereRepository)
    carteService.adauga("1", "Dune", "Frank herbert", "complicat")

    carti = carteService.getAllCarti()

    assert len(carti) == 1
    assert carti[0].getIdEntitate() == "1"

    try:
        carteService.adauga("1", "Ian", "pasiv", "dkfjs")
        assert False
    except DuplicateError:
        ...

def testModificaCarteService():
    carteRepository = Repository()
    inchiriereRepository = Repository()
    carteService = CarteService(carteRepository, inchiriereRepository)
    carteService.adauga("1", "Dune", "Frank herbert", "complicat")

    carteService.modifica("1", "Panama", "Pana ma", "panama")

    carti = carteService.getAllCarti()

    assert len(carti) == 1
    assert carti[0].getIdEntitate() == "1"
    assert carti[0].getTitlu() == "Panama"
    assert carti[0].getAutor() == "Pana ma"
    assert carti[0].getDescriere() == "panama"

    try:
        carteService.modifica("2", "JOasd", "jdhfhf", "dewfh")
        assert False
    except KeyError:
        ...

def testStergeCarteService():
    carteRepository = Repository()
    inchiriereRepository = Repository()
    carteService = CarteService(carteRepository, inchiriereRepository)
    carteService.adauga("1", "Dune", "Frank herbert", "complicat")
    carteService.sterge("1")
    assert len(carteService.getAllCarti()) == 0

    try:
        carteService.sterge("1")
        assert False
    except KeyError:
        ...