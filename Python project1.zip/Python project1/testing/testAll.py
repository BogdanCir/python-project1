from testing.testCarte import testCarte, testSetteriCarte
from testing.testCarteService import testAdaugaCarteService, testModificaCarteService, testStergeCarteService
from testing.testClient import testClient, testSetteri
from testing.testClientService import testAdaugaClientService, testModificaClientService, testStergeClientService
from testing.testInchiriere import testInchiriere, testSetteriInchiriere
from testing.testInchiriereService import testAdaugaInchiriereService, testStergeInchiriereService
from testing.testEntitate import testEntitate
from testing.testClientRepository import testAdaugaClient, testStergeClient, testModificaClient


def testAll():
    testClient()
    testSetteri()
    testCarte()
    testSetteriCarte()
    testEntitate()
    testAdaugaClient()
    testModificaClient()
    testStergeClient()
    testAdaugaClientService()
    testModificaClientService()
    testStergeClientService()
    testAdaugaCarteService()
    testModificaCarteService()
    testStergeCarteService()
    testInchiriere()
    testSetteriInchiriere()
    testAdaugaInchiriereService()
    testStergeInchiriereService()
