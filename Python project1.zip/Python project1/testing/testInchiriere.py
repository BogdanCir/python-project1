from domain.inchiriere import Inchiriere


def testInchiriere():
    inc = Inchiriere("1", "2", "a")

    assert inc.getIdCarte() == "2"
    assert inc.getIdClient() == "1"

def testSetteriInchiriere():
    inc = Inchiriere("1", "2", "a")

    inc.setIdClient("5")
    assert inc.getIdClient() == "5"

    inc.setIdCarte("7")
    assert inc.getIdCarte() == "7"

