from repository.repository import Repository
from service.carteService import CarteService
from service.clientService import ClientService
from service.inchiriereService import InchiriereService


def testAdaugaInchiriereService():
    clientRepository = Repository()
    carteRepository = Repository()
    inchiriereRepository = Repository()
    inchiriereService = InchiriereService(inchiriereRepository, clientRepository, carteRepository)

    clientService = ClientService(clientRepository, inchiriereRepository)
    clientService.adauga("1", "Iacob", 888)
    carteService = CarteService(carteRepository, inchiriereRepository)
    carteService.adauga("2", "Dune", "Frank herbert", "complicat")

    inchiriereService.adaugaInchiriere("1", "2", "10")
    inchirieri = inchiriereService.getAllInchirieri()
    assert len(inchirieri) == 1
    assert inchirieri[0].getIdEntitate() == "10"
    assert inchirieri[0].getIdClient() == "1"
    assert inchirieri[0].getIdCarte() == "2"

def testStergeInchiriereService():
    clientRepository = Repository()
    carteRepository = Repository()
    inchiriereRepository = Repository()
    inchiriereService = InchiriereService(inchiriereRepository, clientRepository, carteRepository)

    clientService = ClientService(clientRepository, inchiriereRepository)
    clientService.adauga("1", "Iacob", 888)
    carteService = CarteService(carteRepository, inchiriereRepository)
    carteService.adauga("2", "Dune", "Frank herbert", "complicat")

    inchiriereService.adaugaInchiriere("1", "2", "10")

    inchiriereService.stergeInchiriere("10")
    inchirieri = inchiriereService.getAllInchirieri()

    assert len(inchirieri) == 0

    try:
        inchiriereService.stergeInchiriere("9")
        assert False
    except KeyError:
        ...

