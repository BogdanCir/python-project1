from domain.exceptions.duplicateError import DuplicateError
from repository.repository import Repository
from service.clientService import ClientService


def testAdaugaClientService():
    clientRepository = Repository()
    inchiriereRepository = Repository()
    clientService = ClientService(clientRepository, inchiriereRepository)
    clientService.adauga("1", "Iacob", 888)

    clienti = clientService.getAllClienti()
    assert len(clienti) == 1
    assert clienti[0].getIdEntitate() == "1"

    try:
        clientService.adauga("1", "Isacob", 889)
        assert False
    except DuplicateError:
        ...

def testModificaClientService():
    clientRepository = Repository()
    inchiriereRepository = Repository()
    clientService = ClientService(clientRepository, inchiriereRepository)
    clientService.adauga("1", "Iacob", 888)
    clientService.modifica("1", "Iona", 999)

    clienti = clientService.getAllClienti()
    assert len(clienti) == 1
    assert clienti[0].getIdEntitate() == "1"
    assert clienti[0].getNume() == "Iona"
    assert clienti[0].getCnp() == 999

    try:
        clientService.modifica("2", "Kakak", 444455)
        assert False
    except KeyError:
        ...

def testStergeClientService():
    clientRepository = Repository()
    inchiriereRepository = Repository()
    clientService = ClientService(clientRepository, inchiriereRepository)
    clientService.adauga("1", "Iacob", 888)
    clientService.sterge("1")

    assert len(clientService.getAllClienti()) == 0

    try:
        clientService.sterge("1")
        assert False
    except KeyError:
        ...