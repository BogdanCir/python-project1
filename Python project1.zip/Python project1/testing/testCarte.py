from domain.carte import Carte


def testCarte():
    carte = Carte("1", "Stoner", "John Williams", "superb")

    assert carte.getTitlu() == "Stoner"
    assert carte.getAutor() == "John Williams"
    assert carte.getDescriere() == "superb"

def testSetteriCarte():
    carte = Carte("1", "Stoner", "John Williams", "superb")

    carte.setTitlu("Moartea lui Ivan Ilich")
    assert carte.getTitlu() == "Moartea lui Ivan Ilich"

    carte.setAutor("Lev Tolstoi")
    assert carte.getAutor() == "Lev Tolstoi"

    carte.setDescriere("dura")
    assert carte.getDescriere() == "dura"
