from domain.client import Client
from domain.exceptions.duplicateError import DuplicateError
from repository.repository import Repository

def testAdaugaClient():
    clientRepository = Repository()
    client = Client("1", "Marcel", 123)

    clientRepository.adauga(client)

    clienti = clientRepository.getAll()
    assert len(clienti) == 1
    assert clienti[0].getIdEntitate() == "1"

    try:
        clientRepository.adauga(client)
        assert False
    except DuplicateError:
        ...

def testModificaClient():
    clientRepository = Repository()
    client = Client("1", "Marcel", 123)
    clientNou = Client("1", "Jupiter", 456)
    clientNouu = Client("2", "marcel", 666)
    clientRepository.adauga(client)

    clientRepository.modifica(clientNou)

    clienti = clientRepository.getAll()
    assert len(clienti) == 1
    assert clienti[0].getIdEntitate() == "1"
    assert clienti[0].getNume() == "Jupiter"
    assert clienti[0].getCnp() == 456

    try:
        clientRepository.modifica(clientNouu)
        assert False
    except KeyError:
        ...

def testStergeClient():
    clientRepository = Repository()
    client = Client("1", "Marcel", 123)
    clientRepository.adauga(client)

    clientRepository.sterge("1")

    try:
        clientRepository.sterge("1")
        assert False
    except KeyError:
        ...
