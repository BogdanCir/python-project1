from domain.entitate import Entitate


def testEntitate():
    entitate = Entitate("1")

    assert entitate.getIdEntitate() == "1"

    entitate.setIdEntitate("2")

    assert entitate.getIdEntitate() == "2"