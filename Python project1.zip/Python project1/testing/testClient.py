from domain.client import Client

def testClient():
    client = Client("1", "Jean", 123)
    assert client.getNume() == "Jean"
    assert client.getCnp() == 123

def testSetteri():
    client = Client("1", "Jean", 123)

    client.setNume("Marie")
    assert client.getNume() == "Marie"

    client.setCnp(456)
    assert client.getCnp() == 456