from repository.repository import Repository
from domain.client import Client


class ClientService:
    def __init__(self, clientRepository: Repository, inchiriereRepository: Repository):
        self.__clientRepository = clientRepository
        self.__inchiriereRepository = inchiriereRepository

    def getAllClienti(self):
        '''
        returneaza o lista de clienti
        :return: o lista de obiecte de tipul Client
        '''
        return self.__clientRepository.getAll()

    def adauga(self, idClient, nume, cnp):
        '''
        adauga un client
        :param idClient: str
        :param nume: str
        :param cnp: int
        :return:
        '''
        client = Client(idClient, nume, cnp)
        self.__clientRepository.adauga(client)

    def modifica(self, idClient, numeNou, cnpNou):
        '''
        modifica un client dupa ID
        :param idClient: str
        :param numeNou: str
        :param cnpNou: cnp
        :return:
        '''
        clientNou = Client(idClient, numeNou, cnpNou)
        self.__clientRepository.modifica(clientNou)

    def sterge(self, idClient):
        """
        sterge un client dupa ID
        :param idClient: str
        :return:
        """
        inchirieri = self.__inchiriereRepository.getAll()
        '''for inchiriere in inchirieri:
            if inchiriere.getIdClient() == idClient:
                self.__inchiriereRepository.sterge(inchiriere.getIdEntitate())'''
        self.__clientRepository.sterge(idClient)
