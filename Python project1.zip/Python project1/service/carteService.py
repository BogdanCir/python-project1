from repository.repository import Repository
from domain.carte import Carte


class CarteService:
    def __init__(self, carteRepository: Repository, inchiriereRepository: Repository):
        self.__carteRepository = carteRepository
        self.__inchiriereRepository = inchiriereRepository

    def getAllCarti(self):
        '''
        returneaza lista de carti
        :return: o lista de obiecte de tipul Carte
        '''
        return self.__carteRepository.getAll()

    def adauga(self, idCarte, titlu, autor, descriere):
        '''
        adauga un obiect de tipul Carte
        :return:
        '''
        carte = Carte(idCarte, titlu, autor, descriere)
        self.__carteRepository.adauga(carte)

    def modifica(self, idCarte, titluNou, autorNou, descriereNoua):
        '''
        modifica o carte dupa ID
        :param idCarte: str
        :param titluNou: str
        :param autorNou: str
        :param descriereNoua: str
        :return:
        '''
        carteNoua = Carte(idCarte, titluNou, autorNou, descriereNoua)
        self.__carteRepository.modifica(carteNoua)

    def sterge(self, idCarte):
        '''
        sterge o carte dupa ID
        :param idCarte: str
        :return:
        '''
        inchirieri = self.__inchiriereRepository.getAll()
        '''for inchiriere in inchirieri:
            if inchiriere.getIdCarte() == idCarte:
                self.__inchiriereRepository.sterge(inchiriere.getIdEntitate())'''
        self.__carteRepository.sterge(idCarte)