from repository.repository import Repository
from domain.inchiriere import Inchiriere
from domain.exceptions.duplicateError import DuplicateError
from domain.DTO.data_class_1 import NrInchirieriAssembler
from domain.DTO.data_class_2 import NumeNrInchirieriAssembler


class InchiriereService:
    def __init__(self, inchiriereRepository: Repository,
                 clientRepository: Repository,
                 carteRepository: Repository):
        self.__inchiriereRepository = inchiriereRepository
        self.__clientRepository = clientRepository
        self.__carteRepository = carteRepository

    def getAllInchirieri(self):
        """
        Returneaza o lista de inchirieri
        :return: o lista de obiecte de tipul Inchiriere
        """
        return self.__inchiriereRepository.getAll()

    def adaugaInchiriere(self, idClient, idCarte, id):
        """
        Adauga o inchiriere
        :param idClient: str
        :param idCarte: str
        :param id: str
        :return:
        """
        if self.__clientRepository.getById(idClient) is None:
            raise KeyError("Clientul cu id-ul introdus nu exista!")
        if self.__carteRepository.getById(idCarte) is None:
            raise KeyError("Cartea cu id-ul introdus nu exista!")

        inchirieri = self.__inchiriereRepository.getAll()
        for inchiriere in inchirieri:
            if inchiriere.getIdClient() == idClient and inchiriere.getIdCarte() == idCarte:
                raise DuplicateError("Cartea cu acest id a fost deja inchiriata de acest client!")

        inchiriere = Inchiriere(idClient, idCarte, id)
        self.__inchiriereRepository.adauga(inchiriere)

    def stergeInchiriere(self, id):
        '''
        Sterge o inchiriere dupa ID-ul inchirierii
        :param id: str
        :return:
        '''
        found = False
        inchirieri = self.__inchiriereRepository.getAll()
        for inchiriere in inchirieri:
            if inchiriere.getIdEntitate() == id:
                self.__inchiriereRepository.sterge(inchiriere.getIdEntitate())
                found = True
        if found is False:
            raise KeyError("Nu exista nicio inchiriere cu acest id!")

    def celeMaiInchiriateCarti(self):
        '''
        Raportează cate închirieri are fiecare carte
        :return: un dictionar care are ca parametri id-urile cartilor si care contine nr de inchirieri ale acestora
                 sau in cazul celei de-a doua versiuni o lista de dto (NrInchirieri)
        '''

        #       inchirieri = self.__inchiriereRepository.getAll()
        #       dict = {}

        #       for inchiriere in inchirieri:
        #           if inchiriere.getIdCarte() in dict:
        #               dict[inchiriere.getIdCarte()] += 1
        #           else:
        #               dict[inchiriere.getIdCarte()] = 1
        #
        #       return dict

        lista = []
        inchirieri = self.__inchiriereRepository.getAll()
        carti = self.__carteRepository.getAll()

        for carte in carti:
            dto = NrInchirieriAssembler.create_nr_inchirieri_dto(carte, inchirieri)
            if dto is not None:
                lista.append(dto)

        return lista

    def clientiOrdonatiNumeNrCartiInchiriate(self):
        '''
        Returneaza clientii cu carti inchiriate ordonati dupa numarul de carti inchiriate si dupa nume
        :return: o lista de dto NumeNrInchirieri
        '''
        '''
        inchirieri = self.__inchiriereRepository.getAll()
        dictio = {}

        for inchiriere in inchirieri:
            idClient = inchiriere.getIdClient()
            client = self.__clientRepository.getById(idClient)
            nume = client.getNume()

            if nume in dictio:
                dictio[nume] += 1
            else:
                dictio[nume] = 1

        sortat = sorted(dictio.items(), key=lambda d: (d[1], d[0]))
        return sortat '''

        lista = []
        clienti = self.__clientRepository.getAll()
        inchirieri = self.__inchiriereRepository.getAll()

        for client in clienti:
            dto = NumeNrInchirieriAssembler.create_nume_nr_inchirieri(client, inchirieri)

            if dto is not None:
                lista.append(dto)

        sortat = sorted(lista, key=lambda d: (d.nr_inchirieri, d.nume_client), reverse=True)
        return sortat

    def primiiCeiMaiActivi(self):
        '''
        Returneaza primii 20% cei mai activi clienti
        :return: o lista de tupluri de forma [('nume', 'nr_inchirieri')] care contine dooar 20% din cei mai activi clienti
        '''
        inchirieri = self.__inchiriereRepository.getAll()
        dictio = {}

        for inchiriere in inchirieri:
            idClient = inchiriere.getIdClient()
            client = self.__clientRepository.getById(idClient)
            nume = client.getNume()

            if nume in dictio:
                dictio[nume] += 1
            else:
                dictio[nume] = 1

        sortat = sorted(dictio.items(), key=lambda d: (d[1], d[0]), reverse=True)

        # am momentan o lista de tupluri de forma [('nume', 'nr_inchirieri')]

        primii = int((20 / 100) * len(sortat))
        listaNoua = []

        for i in range(len(sortat)):
            if i < primii:
                listaNoua.append(sortat[i])

        return listaNoua
