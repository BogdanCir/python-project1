from domain.exceptions.duplicateError import DuplicateError
from service.clientService import ClientService
from service.carteService import CarteService
from service.inchiriereService import InchiriereService


class Consola:
    def __init__(self, clientService: ClientService, carteService: CarteService, inchiriereService: InchiriereService):
        self.__clientService = clientService
        self.__carteService = carteService
        self.__inchiriereService = inchiriereService

    def adaugaClient(self):
        try:
            idClient = input("Introduceti ID-ul clientului: ")
            nume = input("Introduceti numele clilentului: ")
            cnp = int(input("Introduceti CNP-ul clientului: "))
            self.__clientService.adauga(idClient, nume, cnp)
        except DuplicateError as e:
            print(e)
        except ValueError as e:
            print(e)

    def modificaClient(self):
        try:
            idClient = input("Introduceti ID-ul clientului pe care vreti sa-l modificati: ")
            numeNou = input("Introduceti noul nume al clientului: ")
            cnpNou = int(input("Introduceti noul CNP al clientului: "))
            self.__clientService.modifica(idClient, numeNou, cnpNou)
        except ValueError as e:
            print(e)
        except KeyError as e:
            print(e)

    def stergeClient(self):
        try:
            idClient = input("Introduceti ID-ul clientului pe care vreti sa-l stergeti: ")
            self.__clientService.sterge(idClient)
        except KeyError as e:
            print(e)

    def adaugaCarte(self):
        try:
            idCarte = input("Introduceti ID-ul cartii: ")
            titlu = input("Introduceti titlul cartii: ")
            autor = input("Introduceti autorul cartii: ")
            descriere = input("Introduceti descrierea cartii: ")
            self.__carteService.adauga(idCarte, titlu, autor, descriere)
        except DuplicateError as e:
            print(e)

    def modificaCarte(self):
        try:
            idCarte = input("Introduceti id-ul cartii pe care vreti sa o modificati: ")
            titluNou = input("Introduceti noul titlu  al cartii: ")
            autorNou = input("Introduceti noul autor al cartii: ")
            descriereNoua = input("Introduceti noua descriere a cartii: ")
            self.__carteService.modifica(idCarte, titluNou, autorNou, descriereNoua)
        except KeyError as e:
            print(e)

    def stergeCarte(self):
        try:
            idCarte = input("Introduceti ID-ul cartii pe care vreti sa o stergeti: ")
            self.__carteService.sterge(idCarte)
        except KeyError as e:
            print(e)

    def adaugaInchiriere(self):
        try:
            idClient = input("Introduceti ID-ul clientului care a inchirieat cartea: ")
            idCarte = input("Introduceti ID-ul cartii care a fost inchiriata: ")
            id = input("Introduceti ID-ul inchirierii: ")
            self.__inchiriereService.adaugaInchiriere(idClient, idCarte, id)
        except KeyError as e:
            print(e)
        except DuplicateError as e:
            print(e)

    def stergeInchiriere(self):
        try:
            id = input("Introduceti ID-ul inchirierii pe care vreti sa o stergeti: ")
            self.__inchiriereService.stergeInchiriere(id)
        except KeyError as e:
            print(e)

    def nrInchirieriCarte(self):
        rezultat = self.__inchiriereService.celeMaiInchiriateCarti
        print(rezultat)

    def clientiiOrdonatiNumeNrCartiInchiriate(self):
        rezultat = self.__inchiriereService.clientiOrdonatiNumeNrCartiInchiriate()
        print(rezultat)

    def primiiCeiMaiActivi(self):
        print(self.__inchiriereService.primiiCeiMaiActivi())

    def afiseaza(self, entitati):
        for entitate in entitati:
            print(entitate)

    def printMenu(self):
        print("1. Adauga client")
        print("2. Modifica client")
        print("3. Sterge client")
        print("4. Adauga carte")
        print("5. Modifica carte")
        print("6. Sterge carte")
        print("7. Inchiriaza carte")
        print("8. Returneaza carte")
        print("9. Cele mai inchiriate carti")
        print("10. Clienți cu cărți închiriate ordonat dupa: nume, după numărul de cărți închiriate")
        print("11. Primi 20% dintre cei mai activi clienți (nume client si numărul de cărți închiriate)")
        print("a. Afiseaza toti clientii")
        print("b. Afiseaza toate cartile")
        print("i. Afiseaza toate inchirierile")
        print("x. Iesire")

    def menu(self):
        while True:
            self.printMenu()
            opt = input("Introduceti optiunea: ")
            if opt == "1":
                self.adaugaClient()
            elif opt == "2":
                self.modificaClient()
            elif opt == "3":
                self.stergeClient()
            elif opt == "4":
                self.adaugaCarte()
            elif opt == "5":
                self.modificaCarte()
            elif opt == "6":
                self.stergeCarte()
            elif opt == "7":
                self.adaugaInchiriere()
            elif opt == "8":
                self.stergeInchiriere()
            elif opt == "9":
                self.nrInchirieriCarte()
            elif opt == "10":
                self.clientiiOrdonatiNumeNrCartiInchiriate()
            elif opt == "11":
                self.primiiCeiMaiActivi()
            elif opt == "a":
                self.afiseaza(self.__clientService.getAllClienti())
            elif opt == "b":
                self.afiseaza(self.__carteService.getAllCarti())
            elif opt == "i":
                self.afiseaza(self.__inchiriereService.getAllInchirieri())
            elif opt == "x":
                break
            else:
                print("Optiune gresita, reincercati!")
